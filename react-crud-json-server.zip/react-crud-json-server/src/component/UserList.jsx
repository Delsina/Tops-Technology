import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function UserList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const result = await axios.get('http://localhost:5000/users');
    setUsers(result.data);
  };

  const deleteUser = async (id) => {
    await axios.delete(`http://localhost:5000/users/${id}`);
    fetchUsers();
  };

  return (
    <div className="container">
      <h2>User List</h2>
      <Link to="/add-user" className="btn btn-primary">Add User</Link>
      <table className="table">
        <thead>
          <tr>
            <th>User First Name</th>
            <th>User Last Name</th>
            <th>User Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.firstName}</td>
              <td>{user.lastName}</td>
              <td>{user.email}</td>
              <td>
                <Link to={`/update-user/${user.id}`} className="btn btn-info">Update</Link>
                <button onClick={() => deleteUser(user.id)} className="btn btn-danger">Delete</button>
                <Link to={`/view-user/${user.id}`} className="btn btn-primary">View</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default UserList;
