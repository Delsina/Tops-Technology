import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useHistory } from 'react-router-dom';

function UpdateUser() {
  const { id } = useParams();
  const history = useHistory();
  const [user, setUser] = useState({
    firstName: '',
    lastName: '',
    email: ''
  });

  useEffect(() => {
    const fetchUser = async () => {
      const result = await axios.get(`http://localhost:5000/users/${id}`);
      setUser(result.data);
    };
    fetchUser();
  }, [id]);

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`http://localhost:5000/users/${id}`, user);
    history.push('/');
  };

  return (
    <div className="container">
      <h2>Update User</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="firstName" value={user.firstName} onChange={handleChange} />
        <input type="text" name="lastName" value={user.lastName} onChange={handleChange} />
        <input type="email" name="email" value={user.email} onChange={handleChange} />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default UpdateUser;
