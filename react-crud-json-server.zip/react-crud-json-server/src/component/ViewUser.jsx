import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

function ViewUser() {
  const { id } = useParams();
  const [user, setUser] = useState({});

  useEffect(() => {
    const fetchUser = async () => {
      const result = await axios.get(`http://localhost:5000/users/${id}`);
      setUser(result.data);
    };
    fetchUser();
  }, [id]);

  return (
    <div className="container">
      <h2>View User</h2>
      <p>First Name: {user.firstName}</p>
      <p>Last Name: {user.lastName}</p>
      <p>Email: {user.email}</p>
    </div>
  );
}

export default ViewUser;
