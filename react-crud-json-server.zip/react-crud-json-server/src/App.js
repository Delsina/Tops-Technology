import React from 'react';
import { BrowserRouter as Router, Route, Switch, BrowserRouter } from 'react-router-dom';
import UserList from './component/UserList';
import AddUser from './component/AddUser';
import UpdateUser from './component/UpdateUser';
import ViewUser from './component/ViewUser';


function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Router>
          <Route exact path="/" component={UserList} />
          <Route path="/add-user" component={AddUser} />
          <Route path="/update-user/:id" component={UpdateUser} />
          <Route path="/view-user/:id" component={ViewUser} />
          </Router>
       
      </div>
      </BrowserRouter>
  );
}

export default App;
