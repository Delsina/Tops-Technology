import React from "react";


function Helloworld() {
  return (
    <div class="container">
      <div style={{backgroundColor:"black",marginTop:"-8.5px",color:"skyblue",boxSizing:"border-box",textAlign:"center",height:"400px",width:"1548px",padding:"8px",marginLeft:"-8px",fontSize:"40px",fontStyle:"normal"}}> <h1>React JS</h1>
       <img src="https://download.logo.wine/logo/React_(web_framework)/React_(web_framework)-Logo.wine.png" style={{height:"200px",marginLeft:"-10px",marginTop:"-30px"}}></img>
       <div style={{backgroundColor:"skyblue",height:"230px",width:"1550px",marginTop:"11px",marginLeft:"-10px",color:"black",fontSize:"40px",fontSize:"60px",paddingTop:"120px"}}>
        Hello World
       </div>
       </div>

      
        
    </div>
  );
}

export default Helloworld;
