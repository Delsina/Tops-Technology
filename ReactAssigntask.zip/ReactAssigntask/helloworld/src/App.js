import Helloworld from "./Component/Helloworld";


function App() {
  return (
    <div className="App">
      <Helloworld/>
    </div>
  );
}

export default App;
