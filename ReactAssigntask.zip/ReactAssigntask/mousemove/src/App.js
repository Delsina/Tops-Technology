import MouseMove from "./Component/Mousemove";



function App() {
  return (
    <div className="App">
          <MouseMove/>
    </div>
  );
}

export default App;
